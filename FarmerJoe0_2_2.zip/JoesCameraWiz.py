

# $Id: joescamerawiz.py,v 0.1.0 2021/4/25 10:27:10$
#
# --------------------------------------------------------------------------
# Joe's Camera Wiz by Laurence Weedy
# --------------------------------------------------------------------------
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****
# --------------------------------------------------------------------------

bl_info = {
    "name": "Joes Camera Wiz",
    "author" : "Laurence Weedy",
    "version": (0, 1, 0),
    "description" : "Utility for saving settings to multiple cameras",
    "blender": (2, 80, 0),
    "warning" : "",
    "category": "Camera",
}

import bpy

# Global variables


class Camera_Wiz(bpy.types.Panel):
    """Keep some data specific to a camera"""      # Use this as a tooltip for menu items and buttons.
    bl_idname = "PANEL_PT_camerawiz"        # Unique identifier for buttons and menu items to reference.
    bl_label = "Joe\'s Camera Wiz"         # Display name in the interface.
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "output"
    bl_options = {'DEFAULT_CLOSED'}



    def draw(self, context):
        layout = self.layout
        row = layout.row()

        #
        # The original script
        scene = context.scene
        #Check to see if properties exist, if not create them and copy values.
        act_camera = bpy.context.scene.camera
        #bpy.context.scene.frame_start == bpy.context.scene.frame_end:
        cam_name = str(bpy.context.scene.camera.name)
        if act_camera.get('vend') is not None:
            row.label(text = 'Use with CAUTION!', icon='ERROR' )
            row = layout.row()
            row.label(text = 'Saved settings for '+ str(act_camera.name)+ ' (active camera)')
            row = layout.row()
            if bpy.context.scene.use_nodes:
                if str(bpy.data.objects[cam_name]['compositor']) == '1':
                    row.label(text = 'Using Compositor' )
                else:
                    row.label(text = 'Not using Compositor', icon = 'FILE_NEW' )
            else:
                if str(bpy.data.objects[cam_name]['compositor']) == '1':
                    row.label(text = 'Using Compositor', icon = 'FILE_NEW' )
                else:
                    row.label(text = 'Not using Compositor' )
            row = layout.row()
            if bpy.context.scene.frame_start == act_camera['startframe']: 
                row.label(text = 'Start Frame '+ str(bpy.data.objects[cam_name]['startframe']))
            else:
                row.label(text = 'Start Frame '+ str(bpy.data.objects[cam_name]['startframe']), icon = 'FILE_NEW')
            if bpy.context.scene.frame_end == act_camera['endframe']:         
                row.label(text = 'End Frame '+ str(bpy.data.objects[cam_name]['endframe']))
            else:
                row.label(text = 'End Frame '+ str(bpy.data.objects[cam_name]['endframe']), icon = 'FILE_NEW')
            row = layout.row()
            row.label(text = 'Volume Settings')
            row = layout.row()
            if bpy.context.scene.eevee.volumetric_start == act_camera['vstart']: 
                row.label(text = 'Volume Start '+ str("{:.2f}".format(bpy.data.objects[cam_name]['vstart'])))
            else:
                row.label(text = 'Volume Start '+ str("{:.2f}".format(bpy.data.objects[cam_name]['vstart'])), icon = 'FILE_NEW')
            if bpy.context.scene.eevee.volumetric_end == act_camera['vend']:
                row.label(text = 'Volume End '+ str("{:.2f}".format(bpy.data.objects[cam_name]['vend'])))
            else:
                row.label(text = 'Volume End '+ str("{:.2f}".format(bpy.data.objects[cam_name]['vend'])), icon = 'FILE_NEW')
            row = layout.row()           
            
            # Is there a volume material?
            if bpy.data.materials.get('volume') is not None:
                if bpy.data.materials['volume'].use_nodes:
                    ntree = bpy.data.materials['volume'].node_tree
                    
                    ### For Principled Volume
                    if ntree.nodes.get("Principled Volume") is not None:
                        if act_camera.get('volumed') is not None:
                            node = ntree.nodes.get("Principled Volume", None)
                            if node.inputs[2].default_value == act_camera['volumed']:
                                row.label(text = 'Material \'volume\' Principled density node '+ str("{:.2f}".format(bpy.data.objects[cam_name]['volumed'])))
                            else:
                                row.label(text = 'Material \'volume\' Principled density node '+ str("{:.2f}".format(bpy.data.objects[cam_name]['volumed'])), icon = 'FILE_NEW')
                                row = layout.row()

                    ### For Volume Scatter
                    row = layout.row()
                    if ntree.nodes.get("Volume Scatter") is not None:
                        if act_camera.get('volumesd') is not None:
                            node = ntree.nodes.get("Volume Scatter", None)
                            if node.inputs[1].default_value == act_camera['volumesd']:
                                row.label(text = 'Material \'volume\' Scatter density node '+ str("{:.2f}".format(bpy.data.objects[cam_name]['volumesd'])))
                            else:
                                row.label(text = 'Material \'volume\' Scatter density node '+ str("{:.2f}".format(bpy.data.objects[cam_name]['volumesd'])), icon = 'FILE_NEW')
                                row = layout.row()
                    
                    ### For Volume Absorption
                    row = layout.row()
                    if ntree.nodes.get("Volume Absorption") is not None:
                        if act_camera.get('volumead') is not None:
                            node = ntree.nodes.get("Volume Absorption", None)
                            if node.inputs[1].default_value == act_camera['volumead']:
                                row.label(text = 'Material \'volume\' Absorption density node '+ str("{:.2f}".format(bpy.data.objects[cam_name]['volumead'])))
                            else:
                                row.label(text = 'Material \'volume\' Absorption density node '+ str("{:.2f}".format(bpy.data.objects[cam_name]['volumead'])), icon = 'FILE_NEW')
                                                    


                row = layout.row() 
            #box = layout.box()
            row.operator("custom.camwcompute", text='Update from scene')    
            row.operator("custom.cwwrite", text='Copy to scene')   
            
        else:
            row.operator("custom.camwcompute", text='setup camera')

        #return {'FINISHED'}            # Lets Blender know the operator finished successfully.

class CWwrite(bpy.types.Operator):    #May not need
    """Write camera data to main file"""
    bl_idname = 'custom.cwwrite'

    bl_label = 'cwwrite'

    bl_options = {'INTERNAL'}
    def execute(self, context):
        act_camera = bpy.context.scene.camera
        if act_camera['compositor']== 1:
            bpy.context.scene.use_nodes = True
        else:
            bpy.context.scene.use_nodes = False
        bpy.context.scene.frame_start = act_camera['startframe'] 
        bpy.context.scene.frame_end = act_camera['endframe'] 
        bpy.context.scene.eevee.volumetric_start = act_camera['vstart'] 
        bpy.context.scene.eevee.volumetric_end = act_camera['vend'] 
        if bpy.data.materials.get('volume') is not None:
            if bpy.data.materials['volume'].use_nodes:
                    ntree = bpy.data.materials['volume'].node_tree
                    if ntree.nodes.get("Principled Volume") is not None and act_camera.get('volumed') is not None:
                        node = ntree.nodes.get("Principled Volume", None)
                        node.inputs[2].default_value = act_camera['volumed']
                    ### for volume scatter
                    if ntree.nodes.get("Volume Scatter") is not None and act_camera.get('volumesd') is not None:
                        node = ntree.nodes.get("Volume Scatter", None)
                        node.inputs[1].default_value = act_camera['volumesd']
                    ### for volume Absorption
                    if ntree.nodes.get("Volume Absorption") is not None and act_camera.get('volumead') is not None:
                        node = ntree.nodes.get("Volume Absorption", None)
                        node.inputs[1].default_value = act_camera['volumead']                        
        return {'FINISHED'} 

        
class CamWcompute(bpy.types.Operator):
    """Take snapshot of camera data"""
    bl_idname = 'custom.camwcompute'
    bl_label = 'camwcompute'
    bl_options = {'INTERNAL'}

    def execute(self, context):
        #Check to see if properties exist, if not create them and copy values.
        #box = layout.box()
        #Compositor is per scene.. need to interegate current scene
        #row.label(text = 'use Compositor'+ bpy.context.scene.use_nodes)
        #row.label(text = bpy.context.scene.frame_start' to 'bpy.context.scene.frame_end)   
        
        #camera_name = str(bpy.context.scene.camera.name)
        #act_camera = bpy.data.objects['camera_name']
        act_camera = bpy.context.scene.camera
        if bpy.context.scene.use_nodes:
            act_camera['compositor'] = 1
        else:
            act_camera['compositor'] = 0
        act_camera['startframe'] = bpy.context.scene.frame_start
        act_camera['endframe'] = bpy.context.scene.frame_end
        act_camera['vstart'] = bpy.context.scene.eevee.volumetric_start
        act_camera['vend'] = bpy.context.scene.eevee.volumetric_end
        
        if bpy.data.materials.get('volume') is not None:
            if bpy.data.materials['volume'].use_nodes:
                    ntree = bpy.data.materials['volume'].node_tree
                    if ntree.nodes.get("Principled Volume") is not None:
                        node = ntree.nodes.get("Principled Volume", None)
                        act_camera['volumed'] = node.inputs[2].default_value
                    # for volume scatter
                    if ntree.nodes.get("Volume Scatter") is not None:
                        node = ntree.nodes.get("Volume Scatter", None)
                        act_camera['volumesd'] = node.inputs[1].default_value         
                    # for volume Absorption
                    if ntree.nodes.get("Volume Absorption") is not None:
                        node = ntree.nodes.get("Volume Absorption", None)
                        act_camera['volumead'] = node.inputs[1].default_value                           
        return {'FINISHED'}    




    
def register():
    bpy.utils.register_class(Camera_Wiz)
    bpy.utils.register_class(CWwrite)
    bpy.utils.register_class(CamWcompute)



def unregister():
    bpy.utils.unregister_class(Camera_Wiz)
    bpy.utils.unregister_class(CWwrite)
    bpy.utils.register_class(CamWcompute)



# This allows you to run the script directly from Blender's Text editor
# to test the add-on without having to install it.
if __name__ == "__main__":
    register()